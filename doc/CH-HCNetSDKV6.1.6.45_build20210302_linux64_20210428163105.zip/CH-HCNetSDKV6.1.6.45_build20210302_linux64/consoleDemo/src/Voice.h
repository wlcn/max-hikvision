/*
 * Copyright(C) 2010,Custom Co., Ltd 
 *    FileName: Voice.h
 * Description: 
 *     Version: 1.0
 *      Author: panyadong
 * Create Date: 2010-6-7
 * Modification History��
 */

#ifndef _VOICE_H
#define _VOICE_H_

int Demo_Voice();

//����ת��
int Demo_VoiceTrans();





#endif


