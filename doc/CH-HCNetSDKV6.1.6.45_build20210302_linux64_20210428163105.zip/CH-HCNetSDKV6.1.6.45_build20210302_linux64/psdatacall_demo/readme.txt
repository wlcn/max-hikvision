1.将lib下所有的库拷贝到psdatacall_demo下，包括HCNetSDKCom文件夹
2.Device.ini中填入相关的设备信息
3.在终端输入make命令即可生成getpsdata，使用./getpsdata即可执行
  